@objc(WeChat) class WeChat : CDVPlugin {

    //init process
    override func pluginInitialize(){
        print("init pluginInitialize")
    }
    
    //start
    @objc(start:)
    func start(_ command: CDVInvokedUrlCommand) {
        print("WeChat Start")
    }
    

    //echo
    @objc(echo:)
    func echo(command: CDVInvokedUrlCommand) {
        print("echo func")
        
        let obj = JSON(command.arguments[0])
        var pluginResult = CDVPluginResult(status: CDVCommandStatus_ERROR,
                                           messageAs: JSON(["success":false]).dictionaryObject!)
        
        if ( obj.dictionaryObject!.count == 0){
            self.commandDelegate.send(pluginResult, callbackId: command.callbackId)
            //exit func
            return
        }
        
        pluginResult = CDVPluginResult(status: CDVCommandStatus_OK,
                                       messageAs: obj.dictionaryObject! )
        self.commandDelegate!.send( pluginResult, callbackId: command.callbackId)
    }
    
    deinit {

    }
}
