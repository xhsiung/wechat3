cordova.define('cordova/plugin_list', function(require, exports, module) {
module.exports = [
    {
        "id": "cordova-plugin-device.device",
        "file": "plugins/cordova-plugin-device/www/device.js",
        "pluginId": "cordova-plugin-device",
        "clobbers": [
            "device"
        ]
    },
    {
        "id": "cordova-plugins-wechat.wechat",
        "file": "plugins/cordova-plugins-wechat/www/wechat.js",
        "pluginId": "cordova-plugins-wechat",
        "clobbers": [
            "wechat"
        ]
    }
];
module.exports.metadata = 
// TOP OF METADATA
{
    "cordova-plugin-whitelist": "1.3.2",
    "cordova-plugin-device": "1.1.5",
    "cordova-plugins-wechat": "0.0.1"
};
// BOTTOM OF METADATA
});